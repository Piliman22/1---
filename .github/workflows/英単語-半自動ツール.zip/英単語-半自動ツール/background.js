chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "fetchJsonData",
        title: "ターゲットの単語を見る",
        contexts: ["selection"]
    });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "fetchJsonData") {
        const selectedText = info.selectionText.trim();
        const url = "https://raw.githubusercontent.com/Piliman22/target1900-json/refs/heads/main/target_1900.json";

        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error("データの取得に失敗しました");

            const data = await response.json();
            const message = data[selectedText] ? data[selectedText]["word"] : "データが存在しません";

            // ポップアップを表示するスクリプトを実行
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: showPopup,
                args: [message]
            });

        } catch (error) {
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: showPopup,
                args: ["エラー: " + error.message]
            });
        }
    }
});

// ポップアップを生成・表示する関数
function showPopup(message) {
    const popup = document.createElement("div");
    popup.innerText = message;
    popup.style.cssText = `
        position: fixed;
        top: 10%;
        right: 10%;
        padding: 15px;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        border-radius: 8px;
        font-size: 16px;
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.5s;
    `;

    document.body.appendChild(popup);
    setTimeout(() => { popup.style.opacity = "1"; }, 100); // フェードイン

    // 3秒後にポップアップを自動で削除
    setTimeout(() => {
        popup.style.opacity = "0"; // フェードアウト
        setTimeout(() => { popup.remove(); }, 500);
    }, 500);
}
