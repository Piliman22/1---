document.getElementById("get-selection").addEventListener("click", async () => {
    // 現在のタブから選択したテキストを取得
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: getSelectedText,
    }, async (injectionResults) => {
        const selectedKey = injectionResults[0].result.trim();
        if (!selectedKey) {
            document.getElementById("word-display").innerText = "選択された数列がありません。";
            return;
        }

        // JSONデータを取得
        const url = "https://raw.githubusercontent.com/Piliman22/-ver1/refs/heads/main/img/target_1900.json";
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error("データの取得に失敗しました");

            const data = await response.json();
            if (data[selectedKey]) {
                const word = data[selectedKey]["word"];
                document.getElementById("word-display").innerText = `単語: ${word}`;
            } else {
                document.getElementById("word-display").innerText = "指定されたキーがJSONに存在しません。";
            }
        } catch (error) {
            document.getElementById("word-display").innerText = "エラー: " + error.message;
        }
    });
});

// 選択テキストを取得する関数
function getSelectedText() {
    return window.getSelection().toString();
}
